import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BillService } from '../service/bill.service';

@Component({
  selector: 'app-all-bills',
  templateUrl: './all-bills.component.html',
  styleUrls: ['./all-bills.component.css']
})
export class AllBillsComponent implements OnInit {
  
  bills: Observable<any>;

  constructor(private router: Router, private billService: BillService) { }

  ngOnInit(): void {
    this.bills = this.billService.viewAllBills();
  }

}
