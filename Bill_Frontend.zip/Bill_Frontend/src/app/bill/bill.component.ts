import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Bill } from '../entities/bill';
import { BillService } from '../service/bill.service';

@Component({
  selector: 'app-bill',
  templateUrl: './bill.component.html',
  styleUrls: ['./bill.component.css']
})
export class BillComponent implements OnInit {

  billId:number;
  orderId:number
  bill: Bill = new Bill();
  bill1:Observable<any>;

  constructor(private router: Router, private billService: BillService) { }

  ngOnInit(): void {
    this.billId = 3001;
    this.billService.getBillByBillId(this.billId).subscribe((bill1) => {
    this.bill = bill1;
    console.log(this.bill);
    });
  }

}
