import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustbillsComponent } from './custbills.component';

describe('CustbillsComponent', () => {
  let component: CustbillsComponent;
  let fixture: ComponentFixture<CustbillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustbillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustbillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
