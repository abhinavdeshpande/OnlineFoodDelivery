import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Bill } from '../entities/bill';
import { OrderDetails } from '../entities/orderDetails';
import { BillService } from '../service/bill.service';

@Component({
  selector: 'app-custbills',
  templateUrl: './custbills.component.html',
  styleUrls: ['./custbills.component.css']
})
export class CustbillsComponent implements OnInit {
  bills: Observable <any>;
  billId:number;
  custId:number;
  bill: Bill = new Bill();
  order: OrderDetails = new OrderDetails();
  bill1:Observable<any>;

  constructor(private router: Router, private billService: BillService) { }

  ngOnInit(): void {
  
    this.custId = 2500;
    // this.billService.findOrdersByCustomer(this.custId).subscribe((order1)=>{
    //   this.order = order1;
    //   console.log(this.order);
    // });
    this.bills = this.billService.getCustBills(this.custId) //.subscribe((bill1) => {
      
    // this.bill = bill1;
    // //this.bill.order=this.order;
    // console.log(this.bill);
    // });

    
    
  }

}
