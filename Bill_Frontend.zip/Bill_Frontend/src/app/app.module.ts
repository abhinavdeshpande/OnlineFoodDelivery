import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BillComponent } from './bill/bill.component';
import { BillService } from './service/bill.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CustbillsComponent } from './custbills/custbills.component';
import { BillByDateComponent } from './bill-by-date/bill-by-date.component';
import { AllBillsComponent } from './all-bills/all-bills.component';

@NgModule({
  declarations: [
    AppComponent,
    BillComponent,
    CustbillsComponent,
    BillByDateComponent,
    AllBillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [BillService],
  bootstrap: [AppComponent]
})
export class AppModule { }
