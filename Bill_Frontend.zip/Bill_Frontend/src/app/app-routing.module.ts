import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllBillsComponent } from './all-bills/all-bills.component';
import { BillByDateComponent } from './bill-by-date/bill-by-date.component';
import { BillComponent } from './bill/bill.component';
import { CustbillsComponent } from './custbills/custbills.component';


const routes: Routes = [
  { 
    path: 'bill',
   component: BillComponent
  },
  { 
    path: 'cust-bills',
   component: CustbillsComponent
  },
  {
    path: 'date-bills',
    component: BillByDateComponent
  },
  {
    path: 'all-bills',
    component: AllBillsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
