import { FoodCart } from './foodCart';

export class OrderDetails {
    orderId: number;
	orderDate: Date;
	orderStatus: string;
	foodCart: FoodCart = new FoodCart();
}