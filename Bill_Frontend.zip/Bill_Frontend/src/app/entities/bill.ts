import { OrderDetails } from './orderDetails';

export class Bill {
    billId: number;
	order: OrderDetails = new OrderDetails();
	totalItem: string;
	totalCost: string;
	billDate: Date;
}