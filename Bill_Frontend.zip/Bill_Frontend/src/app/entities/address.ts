export class Address {
    addressId: number;
	buildingName: string;
	area: string;
	streetNo: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
}