import { Address } from './address';
import { Items } from './items';

export class Restaurant {
    restaurantId: number;
	restaurantName: string;
	address: Address = new Address();
    items: Items[];
    managerName: string;
    contactNo: string;
}