import { Category } from './category';
import { Restaurant } from './restaurant';

export class Items {
    itemId: number;
	itemName: string;
	category: Category = new Category();
	quantity: number;
    cost: number;
    restaurants: Restaurant[];
}