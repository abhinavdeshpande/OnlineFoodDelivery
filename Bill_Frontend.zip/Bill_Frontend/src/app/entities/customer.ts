import { Address } from './address';

export class Customer {
    customerId: number;
	firstName: string;
	lastName: string;
	gender: string;
    age: string;
    mobileNumber: string;
    email: string;
    address: Address = new Address();
}