import { Customer } from './customer';
import { Items } from './items';

export class FoodCart {
    cartId: number;
	itemQuantity: number;
	customer: Customer = new Customer();
	itemList: Items[];
}