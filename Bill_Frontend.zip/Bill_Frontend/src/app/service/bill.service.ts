import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bill } from '../entities/bill';

@Injectable({
  providedIn: 'root'
})
export class BillService {

  constructor(private http: HttpClient) { }

  generateBill(bill:Bill): Observable<any> {
    return this.http.post('http://localhost:8001/bill/addBill/'+bill.order.orderId, bill);
  }

  getBill(orderId:number): Observable<any> {
    return this.http.get('http://localhost:8001/bill/viewBillByOrder/'+orderId);
  }

  getBillByBillId(billId:number): Observable<any> {
    return this.http.get('http://localhost:8001/bill/viewBill/'+billId);
  }

  viewAllBills(): Observable<any> {
    return this.http.get('http://localhost:8001/bill/allBills');
  }

  getBillsByDate(startDate:string,endDate:string): Observable<any> {
    return this.http.get('http://localhost:8001/bill/viewBillsByDate/'+startDate+'/to/'+endDate);
  }

  getCustBills(custId:number): Observable<any> {
    return this.http.get('http://localhost:8001/bill/viewCustBills/'+custId);
  }


}
