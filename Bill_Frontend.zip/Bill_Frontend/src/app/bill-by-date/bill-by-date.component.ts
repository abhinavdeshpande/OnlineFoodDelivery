import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { BillService } from '../service/bill.service';

@Component({
  selector: 'app-bill-by-date',
  templateUrl: './bill-by-date.component.html',
  styleUrls: ['./bill-by-date.component.css']
})
export class BillByDateComponent implements OnInit {

  bills: Observable <any>;
  date1:string='';
  date2:string='';

  constructor(private billService: BillService) { }

  ngOnInit(): void {
    
  }

  getBillsByDate(){
    this.bills = this.billService.getBillsByDate(this.date1,this.date2);
  }
}
