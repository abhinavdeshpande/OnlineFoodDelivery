import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillByDateComponent } from './bill-by-date.component';

describe('BillByDateComponent', () => {
  let component: BillByDateComponent;
  let fixture: ComponentFixture<BillByDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillByDateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillByDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
