import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurent-owner',
  templateUrl: './restaurent-owner.component.html',
  styleUrls: ['./restaurent-owner.component.css']
})
export class RestaurentOwnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
