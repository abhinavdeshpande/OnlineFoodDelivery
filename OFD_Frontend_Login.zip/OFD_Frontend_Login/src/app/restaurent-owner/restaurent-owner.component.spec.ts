import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurentOwnerComponent } from './restaurent-owner.component';

describe('RestaurentOwnerComponent', () => {
  let component: RestaurentOwnerComponent;
  let fixture: ComponentFixture<RestaurentOwnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurentOwnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurentOwnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
