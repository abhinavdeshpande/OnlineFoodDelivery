import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { BasichomeComponent } from './basichome/basichome.component';
import { CustomerComponent } from './customer/customer.component';
import { LoginComponent } from './login/login.component';
import { RestaurentOwnerComponent } from './restaurent-owner/restaurent-owner.component';
import { SignUpComponent } from './sign-up/sign-up.component';


const routes: Routes = [
{
  path:'',
  component:BasichomeComponent
},
{
  path:'login',
  component:LoginComponent
},
{
  path:'signup',
  component:SignUpComponent
},
{
  path:'customer',
  canActivate:[AuthGuard],
  component:CustomerComponent
},
{
  path:'restaurant-owner',
  canActivate:[AuthGuard],
  component:RestaurentOwnerComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
