import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasichomeComponent } from './basichome.component';

describe('BasichomeComponent', () => {
  let component: BasichomeComponent;
  let fixture: ComponentFixture<BasichomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasichomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasichomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
