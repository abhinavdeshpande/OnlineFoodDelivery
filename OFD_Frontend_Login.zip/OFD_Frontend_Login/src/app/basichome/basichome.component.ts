import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basichome',
  templateUrl: './basichome.component.html',
  styleUrls: ['./basichome.component.css']
})
export class BasichomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
