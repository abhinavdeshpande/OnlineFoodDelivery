import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Login } from '../model/Login';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})

export class SignUpComponent implements OnInit {
  login: Login = new Login();
  message: any;
  confirm_password : string ;
  password: string;
  userName: string;

  constructor(private loginService:LoginService) { }

  ngOnInit(): void {
  }

  signUp(){
    console.log("Inside "+this.password);
      console.log("Inside"+this.confirm_password);
    if(this.login.password == this.confirm_password){
      console.log("Inside if");
      let tmpUser = new Login();
      tmpUser.userName=this.login.userName;
      tmpUser.password= this.login.password;
      console.log(tmpUser);
      this.loginService.signUp(tmpUser).subscribe(data=>{
        console.log(data);
        if(null==data)
          alert("Please enter valid user data");
        else
          alert("New User is added"); 

      })
    }
    else{
      alert("password does not match");
    }
  }
  
     
      /*let resp = this.loginService.signUp(this.login);
      resp.subscribe((data)=>this.message=data);
      alert("Registered successfully");*/


    

}
