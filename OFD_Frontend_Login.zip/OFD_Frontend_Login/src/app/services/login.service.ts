import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  loginUrl="http://localhost:8003/login/findAll"

  constructor(private http: HttpClient) { }

  findUserByUsername(tmpUsername:string,tmpPassword:string):Observable<any>{
    console.log("In service of find by username " +tmpUsername+" and password "+tmpPassword);
    return this.http.get('http://localhost:8003/login/'+tmpUsername+"/"+tmpPassword);
  }

  signUp(login){
    return this.http.post("http://localhost:8003/signup",login);
  }
}
